<?php 
$user = check_auth();
if (!$user->is_admin()) exit('Not authorized.');

$result = mysql_query("select * from collector where collector_status > 0");
$data = array();
while ($row=mysql_fetch_assoc($result)) $data[] = $row;

?>

<h2>COLLECTORS</h2>
<table class="formStyle">
<tr> 
	<td class="form_title">UCLA ID</td>
	<td class="form_title">Name</td>
</tr>
<?php 
foreach ($data as $row)
{
$collector_id = $row['collector_id'];
$collector_first_name = $row['collector_first_name'];
$collector_last_name = $row['collector_last_name'];
?>
<tr valign="middle" align="left"> 
	<td width="25%"><?php echo $row['collector_sid']; ?></td>
	<td width="50%" class="unnamed1"><a href="dashboard/<?php  echo $collector_id; ?>" target="_parent"><?php  echo "$collector_first_name $collector_last_name"; ?></a></td>
</tr>
<?php } ?>
</table>

