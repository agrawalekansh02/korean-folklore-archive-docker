<?php

$user = check_auth();

if (isset($data[0])) {
    $fields = get_record('context',$data[0]);
    foreach ($fields as $k => $v) $$k = $v;
}
?>

<h3>CONTEXT</h3>
      <table class="formStyle">
        <tr> 
          <td align="left" valign="top"> 
            <form name="form1" method="post" action="handler/context/<?php if (isset($data[0])) echo $data[0]; ?>">
              <input name="context_id" type="hidden" value="<?php echo $context_id; ?>">
              <table width="100%" border="0" height="37">
                <tr valign="bottom" align="left"> 
                  <td width="59%" height="7" class="form_title"><label>Name of Event/Expression:</label> <font color="#FF0000">*</font><b> </b></td>
                  <td width="41%" height="7" class="form_title">&nbsp;</td>
                </tr>
                <tr valign="top" align="left"> 
                  <td width="59%" height="2"> 
                    <input name="context_event_name" type="text" value="<?php echo $context_event_name; ?>"  size="30" maxlength="20">
                  </td>
                  <td width="41%" height="2">&nbsp; </td>
                </tr>
              </table>
              <hr size="1" align="center">                                          
              <table width="100%" border="0" height="100">
                <tr valign="middle" align="left"> 
                  <td colspan="3" height="26" class="form_title" valign="top"><label>Type 
                    of event or expression:</label><b class="unnamed1"> (Check all that 
                    apply)</b> <font color="#FF0000">*</font></td>
                  <td width="104" height="26" class="unnamed1">&nbsp; </td>
                </tr>
                <tr valign="bottom" align="left"> 
                  <td height="2" width="120"> 
                    <input type="checkbox" name="context_event_type[]" value="Birthday" <?php if ((strstr($context_event_type, "Birthday"))) echo "checked"; ?>>
                    Birthday</td>
                  <td height="2" width="82"> 
                    <input type="checkbox" name="context_event_type[]" value="Wedding" <?php if ((strstr($context_event_type, "Wedding"))) echo "checked"; ?>>
                    Wedding</td>
                  <td width="132" height="2" class="unnamed1"> 
                    <input type="checkbox" name="context_event_type[]" value="Funeral" <?php if ((strstr($context_event_type, "Funeral"))) echo "checked"; ?>>
                    Funeral </td>
                  <td width="104" height="2" class="unnamed1"> 
                    <input type="checkbox" name="context_event_type[]" value="Graduation" <?php if ((strstr($context_event_type, "Graduation"))) echo "checked"; ?>>
                    Graduation</td>
                </tr>
                <tr valign="bottom" align="left"> 
                  <td height="21" width="120"> 
                    <input type="checkbox" name="context_event_type[]" value="Family Celebration" <?php if ((strstr($context_event_type, "Family Celebration"))) echo "checked"; ?>>
                    Family Celebration</td>
                  <td height="21" width="82"> 
                    <input type="checkbox" name="context_event_type[]" value="Holiday" <?php if ((strstr($context_event_type, "Holiday"))) echo "checked"; ?>>
                    Holiday </td>
                  <td width="132" height="21" class="unnamed1"> 
                    <input type="checkbox" name="context_event_type[]" value="Other Celebration" <?php if ((strstr($context_event_type, "Other Celebration"))) echo "checked"; ?>>
                    Other Celebration</td>
                  <td width="104" height="21" class="unnamed1"> 
                    <input type="checkbox" name="context_event_type[]" value="Anecdote" <?php if ((strstr($context_event_type, "Anecdote"))) echo "checked"; ?>>
                    Anecdote</td>
                </tr>
                <tr valign="bottom" align="left"> 
                  <td height="10" width="120"> 
                    <input type="checkbox" name="context_event_type[]" value="Oral History" <?php if ((strstr($context_event_type, "Oral History"))) echo "checked"; ?>>
                    Oral History</td>
                  <td height="10" width="82"> 
                    <input type="checkbox" name="context_event_type[]" value="Legend" <?php if ((strstr($context_event_type, "Legend"))) echo "checked"; ?>>
                    Legend</td>
                  <td width="132" height="10" class="unnamed1"> 
                    <input type="checkbox" name="context_event_type[]" value="Myth" <?php if ((strstr($context_event_type, "Myth"))) echo "checked"; ?>>
                    Myth</td>
                  <td width="104" height="10" class="unnamed1"> 
                    <input type="checkbox" name="context_event_type[]" value="Fairy Tale" <?php if ((strstr($context_event_type, "Fairy Tale"))) echo "checked"; ?>>
                    Fairy Tale</td>
                </tr>
                <tr valign="bottom" align="left"> 
                  <td height="17" width="120"> 
                    <input type="checkbox" name="context_event_type[]" value="Other Story" <?php if ((strstr($context_event_type, "Other Story"))) echo "checked"; ?>>
                    Other Story</td>
                  <td height="17" width="82"> 
                    <input type="checkbox" name="context_event_type[]" value="Joke" <?php if ((strstr($context_event_type, "Joke"))) echo "checked"; ?>>
                    Joke</td>
                  <td width="132" height="17" class="unnamed1"> 
                    <input type="checkbox" name="context_event_type[]" value="Riddle" <?php if ((strstr($context_event_type, "Riddle"))) echo "checked"; ?>>
                    Riddle</td>
                  <td width="104" height="17" class="unnamed1"> 
                    <input type="checkbox" name="context_event_type[]" value="Slang" <?php if ((strstr($context_event_type, "Slang"))) echo "checked"; ?>>
                    Slang</td>
                </tr>
                <tr valign="bottom" align="left"> 
                  <td height="12" width="120"> 
                    <input type="checkbox" name="context_event_type[]" value="Proverb" <?php if ((strstr($context_event_type, "Proverb"))) echo "checked"; ?>>
                    Proverb</td>
                  <td height="-1" width="82"> 
                    <input type="checkbox" name="context_event_type[]" value="Rhyme" <?php if ((strstr($context_event_type, "Rhyme"))) echo "checked"; ?>>
                    Rhyme</td>
                  <td width="132" height="-1" class="unnamed1"> 
                    <input type="checkbox" name="context_event_type[]" value="Other Folk Speech" <?php if ((strstr($context_event_type, "Other Folk Speech"))) echo "checked"; ?>>
                    Other Folk Speech</td>
                  <td width="104" height="-1" class="unnamed1"> 
                    <input type="checkbox" name="context_event_type[]" value="Song" <?php if ((strstr($context_event_type, "Song"))) echo "checked"; ?>>
                    Song</td>
                </tr>
                <tr valign="bottom" align="left"> 
                  <td height="5" width="120"> 
                    <input type="checkbox" name="context_event_type[]" value="Dance" <?php if ((strstr($context_event_type, "Dance"))) echo "checked"; ?>>
                    Dance</td>
                  <td height="-3" width="82"> 
                    <input type="checkbox" name="context_event_type[]" value="Drama" <?php if ((strstr($context_event_type, "Drama"))) echo "checked"; ?>>
                    Drama</td>
                  <td width="132" height="-3" class="unnamed1"> 
                    <input type="checkbox" name="context_event_type[]" value="Foodways" <?php if ((strstr($context_event_type, "Foodways"))) echo "checked"; ?>>
                    Foodways</td>
                  <td width="104" height="-3" class="unnamed1"> 
                    <input type="checkbox" name="context_event_type[]" value="Clothing" <?php if ((strstr($context_event_type, "Clothing"))) echo "checked"; ?>>
                    Clothing</td>
                </tr>
                <tr valign="bottom" align="left"> 
                  <td height="5" width="120"> 
                    <input type="checkbox" name="context_event_type[]" value="Architecture" <?php if ((strstr($context_event_type, "Architecture"))) echo "checked"; ?>>
                    Architecture</td>
                  <td height="-1" width="82"> 
                    <input type="checkbox" name="context_event_type[]" value="Design" <?php if ((strstr($context_event_type, "Design"))) echo "checked"; ?>>
                    Design</td>
                  <td width="132" height="-1" class="unnamed1"> 
                    <input type="checkbox" name="context_event_type[]" value="Folk Art" <?php if ((strstr($context_event_type, "Folk Art"))) echo "checked"; ?>>
                    Folk Art</td>
                  <td width="104" height="-1" class="unnamed1"> 
                    <input type="checkbox" name="context_event_type[]" value="Tattoo" <?php if ((strstr($context_event_type, "Tattoo"))) echo "checked"; ?>>
                    Tattoo</td>
                </tr>
                <tr valign="top" align="left"> 
                  <td height="23" width="120"> 
                    <input type="checkbox" name="context_event_type[]" value="Piercing" <?php if ((strstr($context_event_type, "Piercing"))) echo "checked"; ?>>
                    Piercing</td>
                  <td height="23" width="82"> 
                    <input type="checkbox" name="context_event_type[]" value="Gesture" <?php if ((strstr($context_event_type, "Gesture"))) echo "checked"; ?>>
                    Gesture</td>
                  <td height="23" width="132"> 
                    <input type="checkbox" name="context_event_type[]" value="Other Material Culture" <?php if ((strstr($context_event_type, "Other Material Culture"))) echo "checked"; ?>>
                    Other Material Culture</td>
                  <td width="104" height="23" class="unnamed1">&nbsp;</td>
                </tr>
              </table>
              <hr size="1" align="center">
              <table width="100%" border="0" height="0">
                <tr valign="bottom" align="left"> 
                  <td height="16" class="form_title" width="167"><label>Time of collection: 
                    <font color="#FF0000">*</font> </label> </td>
                  <td height="16" class="form_title">Date of collection (mm/dd/yyyy)): 
                    <font color="#FF0000">*</font></td>
                </tr>
                <tr valign="middle" align="left"> 
                  <td height="0" width="167"> 
                    <select name="context_time" size="1" class="unnamed1">
                      <option value="00:00:00" <?php if (trim($context_time) == "00:00:00") echo "selected"; ?> >12 AM</option>
                      <option value="01:00:00" <?php if (trim($context_time) == "01:00:00") echo "selected"; ?> >1 AM</option>
                      <option value="02:00:00" <?php if (trim($context_time) == "02:00:00") echo "selected"; ?> >2 AM</option>
                      <option value="03:00:00" <?php if (trim($context_time) == "03:00:00") echo "selected"; ?> >3 AM</option>
                      <option value="04:00:00" <?php if (trim($context_time) == "04:00:00") echo "selected"; ?> >4 AM</option>
                      <option value="05:00:00" <?php if (trim($context_time) == "05:00:00") echo "selected"; ?> >5 AM</option>
                      <option value="06:00:00" <?php if (trim($context_time) == "06:00:00") echo "selected"; ?> >6 AM</option>
                      <option value="07:00:00" <?php if (trim($context_time) == "07:00:00") echo "selected"; ?> >7 AM</option>
                      <option value="08:00:00" <?php if (trim($context_time) == "08:00:00") echo "selected"; ?> >8 AM</option>
                      <option value="09:00:00" <?php if (trim($context_time) == "09:00:00") echo "selected"; ?> >9 AM</option>
                      <option value="10:00:00" <?php if (trim($context_time) == "10:00:00") echo "selected"; ?> >10 AM</option>
                      <option value="11:00:00" <?php if (trim($context_time) == "11:00:00") echo "selected"; ?> >11 AM</option>
                      <option value="12:00:00" <?php if (trim($context_time) == "12:00:00") echo "selected"; ?> >12 PM</option>
                      <option value="13:00:00" <?php if (trim($context_time) == "13:00:00") echo "selected"; ?> >1 PM</option>
                      <option value="14:00:00" <?php if (trim($context_time) == "14:00:00") echo "selected"; ?> >2 PM</option>
                      <option value="15:00:00" <?php if (trim($context_time) == "15:00:00") echo "selected"; ?> >3 PM</option>
                      <option value="16:00:00" <?php if (trim($context_time) == "16:00:00") echo "selected"; ?> >4 PM</option>
                      <option value="17:00:00" <?php if (trim($context_time) == "17:00:00") echo "selected"; ?> >5 PM</option>
                      <option value="18:00:00" <?php if (trim($context_time) == "18:00:00") echo "selected"; ?> >6 PM</option>
                      <option value="19:00:00" <?php if (trim($context_time) == "19:00:00") echo "selected"; ?> >7 PM</option>
                      <option value="20:00:00" <?php if (trim($context_time) == "20:00:00") echo "selected"; ?> >8 PM</option>
                      <option value="21:00:00" <?php if (trim($context_time) == "21:00:00") echo "selected"; ?> >9 PM</option>
                      <option value="22:00:00" <?php if (trim($context_time) == "22:00:00") echo "selected"; ?> >10 PM</option>
                      <option value="23:00:00" <?php if (trim($context_time) == "23:00:00") echo "selected"; ?> >11 PM</option>
                    </select>
                  </td>
                  <td height="0" class="unnamed1"> 
                    <input type="text" name="context_date" id="datepicker" value="<?php if (!empty($context_date)) echo $context_date; ?>" size="12" maxlength="12">
                  </td>
                </tr>
              </table>
              <hr size="1" align="center">
              <table width="100%" border="0">
                <tr valign="bottom" align="left"> 
                  <td colspan="2" height="8" class="form_title"> Weather on the 
                    day of collection: <font color="#FF0000">*</font></td>
                  <td height="8" class="form_title" colspan="2">&nbsp; </td>
                </tr>
                <tr valign="middle" align="left"> 
                  <td width="25%" height="1" class="unnamed1"> 
                    <input type="radio" name="context_weather" value="Sunny" <?php if (trim($context_weather) == "Sunny") echo "checked"; ?> >
                    Sunny </td>
                  <td width="25%" height="1" class="unnamed1"> 
                    <input type="radio" name="context_weather" value="Overcast" <?php if (trim($context_weather) == "Overcast") echo "checked"; ?> >
                    Overcast</td>
                  <td width="25%" height="1" class="unnamed1"> 
                    <input type="radio" name="context_weather" value="Raining" <?php if (trim($context_weather) == "Raining") echo "checked"; ?> >
                    Raining</td>
                  <td width="25%" height="1" class="unnamed1"> 
                    <input type="radio" name="context_weather" value="Snowing" <?php if (trim($context_weather) == "Snowing") echo "checked"; ?> >
                    Snowing</td>
                </tr>
              </table>
              <hr size="1" align="center">
              <table width="100%" border="0" height="121">
                <tr valign="bottom" align="left"> 
                  <td colspan="2" height="16" class="form_title"><b>Language(s) 
                    of collection: <font color="#FF0000">*</font></b> </td>
                  <td width="100" height="16" class="form_title">&nbsp;</td>
                  <td width="127" height="16" class="form_title">&nbsp; </td>
                </tr>
                <tr valign="middle" align="left"> 
                  <td width="104" height="13" class="unnamed1"> 
                    <input type="checkbox" name="context_language[]" value="Korean" <?php if ((strstr($context_language, "Korean"))) echo "checked"; ?> >
                    Korean</td>
                  <td width="107" height="13" class="unnamed1"> 
                     
                      <input type="checkbox" name="context_language[]" value="Japanese" <?php if ((strstr($context_language, "Japanese"))) echo "checked"; ?> >
                      Japanese
                  </td>
                  <td width="100" height="13" class="unnamed1"> 
                    <input type="checkbox" name="context_language[]" value="Chinese" <?php if ((strstr($context_language, "Chinese"))) echo "checked"; ?> >
                    Chinese</td>
                  <td width="127" height="13" class="unnamed1"> 
                    <input type="checkbox" name="context_language[]" value="English" <?php if ((strstr($context_language, "English"))) echo "checked"; ?> >
                    English</td>
                </tr>
                <tr valign="middle" align="left"> 
                  <td width="104" height="5" class="unnamed1"> 
                    <input type="checkbox" name="context_language[]" value="Portugese" <?php if ((strstr($context_language, "Portugese"))) echo "checked"; ?> >
                    Portuguese</td>
                  <td width="107" height="5" class="unnamed1"> 
                    <input type="checkbox" name="context_language[]" value="Other" <?php if ((strstr($context_language, "Other"))) echo "checked"; ?> >
                    Other</td>
                  <td width="100" height="5" class="unnamed1">&nbsp; </td>
                  <td width="127" height="5" class="unnamed1">&nbsp; </td>
                </tr>
                <tr valign="bottom" align="left"> 
                  <td colspan="2" height="2" class="form_title">If other, please 
                    specify:</td>
                  <td width="100" height="2" class="form_title">&nbsp;</td>
                  <td width="127" height="2" class="form_title">&nbsp;</td>
                </tr>
                <tr valign="bottom" align="left"> 
                  <td colspan="2" height="12" class="form_title"> 
                    <input type="text" name="context_other_language" value="<?php echo $context_other_language; ?>" size="30">
                  </td>
                  <td width="100" height="12" class="form_title">&nbsp;</td>
                  <td width="127" height="12" class="form_title">&nbsp;</td>
                </tr>
              </table>
              <hr size="1" align="center">

              <table width="100%" border="0" height="20">
                <tr valign="bottom" align="left"> 
                  <td colspan="2" height="8" class="form_title"> Place of collection: 
                    <font color="#FF0000">*</font></td>
                  <td height="8" class="form_title" colspan="2">&nbsp; </td>
                </tr>

                <tr valign="middle" align="left"> 
                  <td width="30%" height="16" class="unnamed1"> 
                    <input type="radio" name="context_place" value="Business" <?php if (trim($context_place) == "Business") echo "checked"; ?> >
                    Business</td>
                  <td width="35%" height="16" class="unnamed1"> 
                     
                      <input type="radio" name="context_place" value="Residence" <?php if (trim($context_place) == "Residence") echo "checked"; ?> >
                      Residence
                  </td>
                  <td width="35%" height="16" class="unnamed1"> 
                    <input type="radio" name="context_place" value="Public Place" <?php if (trim($context_place) == "Public Place") echo "checked"; ?> >
                    Public Place</td>
                </tr>

              </table>
              <hr size="1" align="center">
              
              <table width="100%" border="0">
                <tr valign="bottom" align="left"> 
                  <td colspan="2" height="16" class="form_title"> Address of Collection:</td>
                  <td height="16">&nbsp; </td>
                </tr>
                <tr valign="bottom" align="left"> 
                  <td width="30%" height="8" class="form_title">Street Address: 
                  </td>
                  <td width="35%" height="8" class="form_title"><b>City:</b> </td>
                  <td width="35%" height="8" class="form_title"><b>State/Province: </b></td>
                </tr>
                <tr valign="top" align="left"> 
                  <td width="30%" height="13"> 
                    <input type="text" name="context_street" value="<?php echo $context_street; ?>" size="19" maxlength="50">
                  </td>
                  <td width="35%" height="13"> 
                     
                      <input name="context_city" type="text" value="<?php echo $context_city; ?>" size="15" maxlength="30">
                    
                  </td>
                  <td width="35%" height="13"> 
                    <input type="text" name="context_state" value="<?php echo $context_state; ?>" size="3" maxlength="20">
                  </td>
                </tr>
                <tr valign="middle" align="left"> 
                  <td width="30%" height="5" class="form_title">Zipcode/Postal Code: </td>
                  <td width="35%" height="5" class="form_title"><b>Country:</b> 
                  </td>
                  <td width="35%" height="5" class="form_title">&nbsp;</td>
                </tr>
                <tr valign="middle" align="left"> 
                  <td width="30%" height="2" class="unnamed1"> 
                    <input type="text" name="context_zipcode" value="<?php echo $context_zipcode; ?>" size="19" maxlength="20">
                  </td>
                  <td width="35%" height="2" class="unnamed1"> 
                    <input type="text" name="context_country" value="<?php echo $context_country; ?>" size="15" maxlength="20">
                  </td>
                  <td width="35%" height="2" class="unnamed1">&nbsp;</td>
                </tr>
              </table>
              <hr size="1" align="center">
              
              <table width="100%" border="0">
                <tr valign="bottom" align="left"> 
                  <td colspan="3" height="8" class="form_title"><b>If the address 
                      of collection is unknown, </b><b> please enter GPS Info 
                      of Collection: </b> 
                    </td>
                </tr>
                <tr valign="middle" align="left"> 
                  <td width="29%" height="8" class="form_title" valign="bottom">Latitude: 
                  </td>
                  <td width="36%" height="8" valign="bottom"> 
                    &nbsp;</td>
                  <td width="35%" height="8" class="unnamed1">&nbsp; </td>
                </tr>
                <tr valign="middle" align="left"> 
                  <td width="29%" height="9" class="unnamed1">Direction:</td>
                  <td width="36%" height="9" class="unnamed1">Degrees [0,180): 
                  </td>
                  <td width="35%" height="9" class="unnamed1">Minutes.Seconds:</td>
                </tr>
                <tr valign="middle" align="left"> 
                  <td width="29%" height="0" class="unnamed1"> 
                    <select name="context_latitude_direction" size="1">
                      <option value="*">Please Select</option>
                      <option value="N" <?php if (trim($context_latitude_direction) == "N") echo "selected"; ?> >N</option>
                      <option value="S" <?php if (trim($context_latitude_direction) == "S") echo "selected"; ?> >S</option>
                    </select>
                  </td>
                  <td width="36%" height="-4" class="unnamed1">
                    <input type="text" name="context_latitude_degree" value="<?php echo $context_latitude_degree; ?>" size="15" maxlength="3">
                  </td>
                  <td width="35%" height="-4" class="unnamed1">
                    <input type="text" name="context_latitude_minsec" value="<?php echo $context_latitude_minsec; ?>" size="15" maxlength="6">
                  </td>
                </tr>
                <tr valign="bottom" align="left"> 
                  <td width="29%" height="8" class="form_title">Longitude: </td>
                  <td width="36%" height="8" class="unnamed1">&nbsp;</td>
                  <td width="35%" height="8" class="unnamed1">&nbsp;</td>
                </tr>
                <tr valign="middle" align="left"> 
                  <td width="29%" height="1" class="unnamed1">Direction:</td>
                  <td width="36%" height="-1" class="unnamed1">Degrees [0,180):</td>
                  <td width="35%" height="-1" class="unnamed1">Minutes.Seconds:</td>
                </tr>
                <tr valign="middle" align="left"> 
                  <td width="29%" height="1" class="unnamed1"> 
                    <select name="context_longitude_direction" size="1">
                      <option value="*">Please Select</option>
                      <option value="E" <?php if (trim($context_longitude_direction) == "E") echo "selected"; ?> >E</option>
                      <option value="W" <?php if (trim($context_longitude_direction) == "W") echo "selected"; ?> >W</option>
                    </select>
                  </td>
                  <td width="36%" height="1" class="unnamed1">
                    <input type="text" name="context_longitude_degree" value="<?php echo $context_longitude_degree; ?>" size="15" maxlength="3">
                  </td>
                  <td width="35%" height="1" class="unnamed1">
                    <input type="text" name="context_longitude_minsec" value="<?php echo $context_longitude_minsec; ?>" size="15" maxlength="6">
                  </td>
                </tr>
              </table>
              <hr size="1" align="center">

              <table width="100%" border="0" height="105">
                <tr valign="bottom" align="left"> 
                  <td colspan="2" height="7" class="form_title"><b>Consultants present: </b></td>
                  <td width="41%" height="7" class="form_title">&nbsp;</td>
                </tr>
                <tr valign="middle" align="left">
                <?php
                    $count = 0;
                    if (isset($collector_id)) $data = get_records('consultant', $collector_id);
                    else $data = get_records('consultant', $user->get('id'));

                    $consultants = (isset($context_consultants)) ? explode(',', $context_consultants) : array();
                    foreach ($data as $row)
                    {
                        $count++;
                ?>
                    <td height="2" width="82">
                    <input type="checkbox" name="context_consultants[]" value="<?php echo $row['consultant_id']; ?>" <?php if (in_array($row['consultant_id'], $consultants)) echo 'checked'; ?>><?php echo $row['consultant_first_name'],' ',$row['consultant_last_name']; ?>
                    </td>
                <?php
                    if (!($count%3)) echo '</tr><tr>';
                    }
                ?>
                </tr>
                <tr valign="top" align="left"> 
                  <td colspan="2" height="10" valign="bottom"><span class="form_title">Number 
                    of others present:</span> </td>
                  <td width="41%" height="10">&nbsp;</td>
                </tr>
                <tr valign="middle" align="left"> 
                  <td width="32%" height="25" class="unnamed1"> 
                    <input type="text" name="context_otherpresent_num" value="<?php echo $context_otherpresent_num; ?>" size="8" maxlength="5">
                  </td>
                  <td width="27%" height="25">&nbsp; </td>
                  <td width="41%" height="25">&nbsp;</td>
                </tr>
                <tr valign="middle" align="left"> 
                  <td colspan="2" height="10" class="unnamed1"><span class="form_title">Age 
                    of others present:</span> (Check all that apply)</td>
                  <td width="41%" height="-3">&nbsp;</td>
                </tr>
                <tr valign="middle" align="left"> 
                  <td width="32%" height="10" class="unnamed1"> 
                    <input type="checkbox" name="context_otherpresent_age[]" value="Younger" <?php if ((strstr($context_otherpresent_age, "Younger"))) echo "checked";?>>
                    Younger</td>
                  <td width="27%" height="-1" class="unnamed1"> 
                    <input type="checkbox" name="context_otherpresent_age[]" value="Same Age" <?php if ((strstr($context_otherpresent_age, "Same Age"))) echo "checked";?>>
                    Same-age-as</td>
                  <td width="41%" height="-1" class="unnamed1"> 
                    <input type="checkbox" name="context_otherpresent_age[]" value="Older" <?php if ((strstr($context_otherpresent_age, "Older"))) echo "checked";?>>
                    Older than main consultant</td>
                </tr>
              </table>
              <hr size="1" align="center">

              <table width="100%" border="0" height="30">              
                <tr valign="bottom" align="left"> 
                  <td colspan="2" height="16" class="form_title"><b>Method of 
                    collection :</b></td>
                  <td width="100" height="16" class="form_title">&nbsp;</td>
                  <td width="127" height="16" class="form_title">&nbsp; </td>
                </tr>

                <tr valign="middle" align="left"> 
                  <td width="104" height="13" class="unnamed1"> 
                    <input type="checkbox" name="context_media[]" value="Tape Recorder" <?php if ((strstr($context_media, "Tape Recorder"))) echo "checked"; ?> >
                    Tape-Recorder</td>
                  <td width="107" height="13" class="unnamed1"> 
                     
                      <input type="checkbox" name="context_media[]" value="Video Camera" <?php if ((strstr($context_media, "Video Camera"))) echo "checked"; ?> >
                      Video Camera
                  </td>
                  <td width="100" height="13" class="unnamed1"> 
                    <input type="checkbox" name="context_media[]" value="Still Camera" <?php if ((strstr($context_media, "Still Camera"))) echo "checked"; ?> >
                    Still Camera</td>
                  <td width="127" height="13" class="unnamed1"> 
                    <input type="checkbox" name="context_media[]" value="Notes" <?php if ((strstr($context_media, "Notes"))) echo "checked"; ?> >
                    Notes </td>
                </tr>
              </table>
              <hr size="1" align="center">
              
              <table width="100%" border="0">
                <tr valign="bottom" align="left"> 
                  <td width="30%" height="16" class="form_title" valign="top">Context 
                    Description: <font color="#FF0000">*</font></td>
                  <td colspan="2" height="80" class="form_title" rowspan="2"> 
                    
                      <textarea name="context_description" wrap="VIRTUAL" cols="50" rows="10" class="unnamed1"><?php echo $context_description; ?></textarea>
                    
                  </td>
                </tr>
                <tr valign="middle" align="left"> 
                  <td width="30%" height="30" class="unnamed1">&nbsp; </td>
                </tr>
                <tr valign="middle" align="left"> 
                  <td height="5" class="unnamed1">&nbsp; </td>
                  <td height="5" class="unnamed1">&nbsp; </td>
                  <td height="5" class="unnamed1">&nbsp; </td>
                </tr>
              </table>
              <hr size="1" align="center">
              <table width="100%" border="0" cellpadding="0" cellspacing="0">
                <tr> 
                  <td class="unnamed1" style="text-align: center;"> 
                    <input type="submit" class="unnamed1 btnSubmit">&nbsp;&nbsp;&nbsp;
                    <a href="dashboard">Cancel</a>&nbsp;&nbsp;&nbsp;
                  </td>
                </tr>
              </table>
              </form>
          </td>
        </tr>
      </table>