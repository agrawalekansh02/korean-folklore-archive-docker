
<?php

function getLink() {
	$args = func_get_args();
	$str = array();
	foreach ($args as $a) $str[] = trim(ucwords($a));
	$str = implode(' ', $str);
	if (strlen(trim($str)) == 0) return 'Empty';
	else return $str;
}


	$user = check_auth();

	$collector_id = $user->get('id');
	if ($user->is_admin() && isset($data[0]) && $data[0] > 0) {
		$collector_id = $data[0];
	}


	$collector_result = mysql_query("select * from collector where collector_id=$collector_id");
	if ($row=mysql_fetch_assoc($collector_result)) foreach ($row as $k => $v) $$k = $v;
	else {echo 'Invalid Collector'; return false;}

	
	$context_result = mysql_query("select * from context where collector_id=$collector_id");
	$consultant_result = mysql_query("select * from consultant where collector_id=$collector_id");
	$data_result = mysql_query("select * from data where collector_id=$collector_id");
?>
<h2>ARCHIVE DASHBOARD</h2>
<table class="formStyle" cellspacing=3px>
<tr>
	<td width="50%">
		<h3>Collector Profile</h3>
                   <strong><a href="collector/<?php echo $collector_id; ?>" target="_self"><?php  echo getLink($collector_first_name, $collector_last_name); ?></a></strong><br>
                  <a href="mailto:<?php  echo $collector_email?>"> <?php  echo $collector_email?></a><br>
					<?php  echo $collector_street, ", ", $collector_city, ", ", $collector_state, " ", $collector_zipcode, " ", $collector_country; ?><br>
					DOB: <?php  echo $collector_dob;?><br>
					Age: <?php  echo $collector_age; ?><br>
					Gender: <?php  echo $collector_gender; ?><br>
					Marital Status: <?php  echo $collector_marital_status; ?><br>
					Occupation: <?php  echo $collector_occupation;?><br>
					Educational Level: <?php  echo $collector_edu_level;?><br>
					Heritage: <?php  echo $collector_heritage ?><br>
					Languages Spoken: <?php  echo $collector_language; ?><br>
	</td>
	<td width="50%">
		<h3>Contexts</h3>

			<?php 
			// Populate the contexts that are associated with this collector
			while($row=mysql_fetch_assoc($context_result))
			{
				// get context_id from $context_result
				$context_id=$row['context_id'];
				// fetch info about that context from db
				?> <strong><a href="context/<?php  echo $context_id; ?>" target="_self"> <?php  echo getLink($row['context_event_name']); ?> </a></strong><br>
				  <t>Date: <?php  echo $row['context_date']; ?> <br>
				  <t>Time: <?php  echo $row['context_time']; ?> <br>
				  <t>Description: <?php  $subcontext = substr($row['context_description'], 0, 50); echo trim($subcontext), "..."; ?> <br>
			<?php }	?>


	</td>
</tr>
<tr>
	<td style="line-height: 1.4;">
		<h3>Consultants</h3>
			<?php 
			// Populate consultants that are associated with this collector	
			while($row=mysql_fetch_assoc($consultant_result))
			{
				// take consultant id from consultant_result list
				$consultant_id=$row['consultant_id'];

								
				// create link to consultant with corresponding consultant id
			?>	<strong><a href="consultant/<?php echo $consultant_id;?>" target="_self"><?php echo getLink($row['consultant_first_name'], $row['consultant_last_name']);?>  </a></strong><br/>
			<?php 				
			};
			?>
	
	</td>
	<td>
		<h3>Data</h3>

			<?php 
			// Populate data that are associated with this collector
			while($row=mysql_fetch_assoc($data_result))
			{
				// take data_id from data_result array
				$data_id=$row['data_id'];
				// create link to data item with corresponding data_id
				?><strong><a href="data/<?php  echo $data_id; ?>" target="_self"><?php  echo getLink($row['data_project_title']); ?> </a></strong><br>		
				<t>Description: <?php  $subdata = substr($row['data_description'], 0, 100); echo trim($subdata), "..."; ?> <br>		
				<t>Filename: <?php  echo $row['data_file_name']; ?> <br>
			<?php 
			};	
			?>

	</td>
</tr>
</table>

