<?php

$user = check_auth();

if (isset($data[0])) {
    $fields = get_record('data',$data[0]);
    if (count($fields) == 0) {
        echo 'Invalid URL';
        return false;
    }
    foreach ($fields as $k => $v) $$k = $v;
}
?>
<h3>FIELD DATA</h3>
      <table class="formStyle">
        <tr> 
          <td align="left" valign="top" height="336"> 
            <form name="form1" enctype="multipart/form-data" method="post" action="handler/data/<?php if (isset($data[0])) echo $data[0]; ?>">
              <input name="data_id" type="hidden" value="<?php echo $data_id; ?>">
              <table width="100%" border="0" height="254">
                <tr valign="bottom" align="left"> 
                  <td colspan="2" height="10" class="form_title">Title of project: 
                    <font color="#FF0000">*</font> </td>
                  <td width="119" height="10" class="form_title"><b> </b></td>
                </tr>
                <tr valign="top" align="left"> 
                  <td colspan="2" height="27"> <input name="data_project_title" type="text" value="<?php echo $data_project_title; ?>" size="40" maxlength="50"></td>
                  <td width="243" height="27"><b> </b></td>
                </tr>
                <tr valign="middle" align="left"> 
                  <td colspan="2" height="10" class="form_title">Context: <font color="#FF0000">*</font></td>
                  <td width="243" height="10" class="form_title">Main Consultant:</td>
                </tr>
                <?php  
                    if (isset($collector_id)) $context = get_records('context', $collector_id);
                    else $context = get_records('context', $user->get('id'));

                    foreach ($context as $row)
                    {
                ?>
                <tr valign="middle" align="left" class="contextset"> 
                    <td colspan="2" height="2"> 
                        &nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="context_id" value="<?php echo $row['context_id']; ?>" <?php if ($context_id == $row['context_id']) echo "checked"; ?>><?php echo $row['context_event_name']; ?>
                    </td>
                    <td height="2" width="243">
                        <select name="consultant_id">
                        <option value="-1">None</option>
                        <?php
                            $sql = 'select * from consultant where consultant_id in ('.$row['context_consultants'].')';
                            $result = mysql_query($sql);
                            while($rec = mysql_fetch_assoc($result))
                            {
                        ?>
                        <option value="<?php echo $rec['consultant_id']; ?>" <?php if ( ($context_id == $row['context_id']) && ($rec['consultant_id']==$consultant_id) ) echo "selected"; ?> ><?php echo $rec['consultant_first_name'],' ',$rec['consultant_last_name']; ?></option>
                        <?php
                            }
                        ?>
                        </select> 
                    </td>
                </tr>
                <?php
                    } 
                ?>
                <tr valign="middle" align="left">
                </tr>
                <tr valign="middle" align="left"> 
                  <td width="80" height="18" class="form_title" valign="top"> 
                    Collection Media:</td>
                  <td width="119" height="18" class="form_title" valign="top"> 
                    Data Description: <font color="#FF0000">*</font></td>
                  <td width="243" height="18">&nbsp;</td>
                </tr>
                <tr valign="middle" align="left"> 
                  <td height="126" class="form_title" valign="top"> 
                  <table width="100%" border="0">
                      <tr> 
                        <td>&nbsp;</td>
                        <td> <input type="radio" name="data_type" value="Fieldnotes" <?php if (trim($data_type) == "Fieldnotes") echo "checked"; ?> >
                          Fieldnotes</td>
                      </tr>
                      <tr> 
                        <td>&nbsp;</td>
                        <td> <input type="radio" name="data_type" value="Images" <?php if (trim($data_type) == "Images") echo "checked"; ?> >
                          Images</td>
                      </tr>
                      <tr> 
                        <td>&nbsp;</td>
                        <td> <input type="radio" name="data_type" value="Video" <?php if (trim($data_type) == "Video") echo "checked"; ?> >
                          Video</td>
                      </tr>
                      <tr> 
                        <td>&nbsp;</td>
                        <td> <input type="radio" name="data_type" value="Audio" <?php if (trim($data_type) == "Audio") echo "checked"; ?> >
                          Audio</td>
                      </tr>
                    </table>
                    </td>
                  <td colspan="2" height="126" valign="top" align="left"> 
                    <textarea name="data_description" wrap="VIRTUAL" cols="50" rows="10"><?php echo $data_description; ?></textarea> 
                  </td>
                </tr>
              </table>
              <hr size="1" align="center">

                    <table width="100%" border="0" cellspacing="0" cellpadding="1" height="0">
                      <tr> 
                        <td colspan="3" align="left" height="18" class="form_title" valign="bottom"> 
                        <?php echo empty($data_file)? 
                              "Upload Media File (<2MB):" : 
                            "Uploaded Media File: "; 
                          ?> 
                        </td>
                      </tr>
                      <tr valign="bottom" align="left"> 
                      <?php if (empty($data_file)) { ?> 
                        <td colspan="3" height=1 class=unnamed1>
                        <input name="upload_file" type="file">
                        </td> 
                      <?php } else { ?> 
                        <td height=1> File Name: <a href="download/data/<?php echo $data_id; ?>" target="_blank"><?php echo $data_file_name; ?></a> </td> 
                        <td height=1> File Type: <?php echo $data_file_type; ?> </td> 
                        <td height=1> File Size: <?php echo $data_file_size; ?> Bytes </td>
                      <?php } ?>
                      </tr>
                    </table>
                    <hr size="1" align="center">          
              <table width="100%" border="0" cellpadding="0" cellspacing="0">
                <tr> 
                  <td style="text-align: center;"> 
                    <input type="submit" value="Submit" class="unnamed1 btnSubmit">&nbsp;&nbsp;&nbsp;
                    <a href="dashboard">Cancel</a>&nbsp;&nbsp;&nbsp;
                    <?php if ($action == "edit") { ?>
                    <input type="submit" name="Delete" value="Delete">&nbsp;&nbsp;&nbsp;
                    <?php } ?>
                  </td>
                </tr>
              </table>
            </form>
          </td>
        </tr>
      </table>
<script>
$(function(){
	$('.contextset select').each(function(){
		var val = $(this).val();
		if (val == -1) $(this).removeAttr('name');
		else $(this).attr('name','consultant_id');
	}); 
	$('.contextset select').change(function(){
		var val = $(this).val();
		if (val == -1) $(this).removeAttr('name');
		else $(this).attr('name','consultant_id');
	}); 
});
</script>