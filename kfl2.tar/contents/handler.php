<?php
global $user;
if (!$user->auth) {exit('Not authorized');}

function get_set_sql($f) {
	$sql_str = array();
	foreach ($f as $k => $v) {
		$sql_str[] = "$k='".mysql_real_escape_string($v)."'";
	}
	return implode(', ', $sql_str);
}

function get_file() {
	$user = get_user();
	$data = false;
	foreach ($_FILES as $name => $data) {
		if ($data['size'] > 10) {
			$id = $user['collector_id'] . substr(time(), -6);
			move_uploaded_file($data['tmp_name'], "files/" . $id);	
			$data['files'] = $id;
			// only one file can be uploaded at a time. 
			break;
		}
	}
	return $data;
}

function process_consultant($f, $id=false) {
	if (!$id) unset($f['consultant_id']);
	if ($fd = get_file()) {
		$f['consultant_file_name']	= $fd['name'];
		$f['consultant_file_type'] = $fd['type'];
		$f['consultant_file_size'] = $fd['size'];
		$f['consultant_consent_form'] = $fd['files'];
	}
	return $f;
}
function process_context($f, $id=false) {
	if (!$id) unset($f['context_id']);
	return $f;
}

function add_context_consultant($id, $consultants) {

}

function process_collector($f, $id=false) {
	global $user;
	if (!$id) {
		if ($_POST['passcode'] != PASSCODE) exit('Invalid Passcode');
		unset($f['collector_id']);
		unset($f['passcode']);
		$f['collector_sid'] = $user->auth;
		$f['collector_status'] = 1;
	}
	return $f;
}
function process_data($f, $id=false) {
	if (!$id) unset($f['data_id']);
	if ($fd = get_file()) {
		$f['data_file_name'] = $fd['name'];
		$f['data_file_type'] = $fd['type'];
		$f['data_file_size'] = $fd['size'];
		$f['data_file'] = $fd['files'];
	}
	return $f;
}
?>
<?php
$table = $data[0];
$id = (isset($data[1])) ? $data[1] : false;
$sql_set = array();
foreach ($_POST as $k => $v) {
	if (is_array($v)) $v = implode(',', $v);
	$sql_set[$k] = $v;
}
switch($table) {
	case 'consultant':
		$sql_set = process_consultant($sql_set, $id);
		break;
	case 'context':
		$sql_set = process_context($sql_set, $id);
		break;
	case 'collector':
		$sql_set = process_collector($sql_set, $id);
		break;
	case 'data':
		$sql_set = process_data($sql_set, $id);
		break;
}
if (!$id) {
	if ($table != 'collector') $sql_set['collector_id'] = $user->get('id');
	$sql = "insert into $table set " . get_set_sql($sql_set);
	mysql_query($sql);
	$id = mysql_insert_id();
} else {
	$sql = "update $table set ".get_set_sql($sql_set)." where ${table}_id=$id " . get_auth_sql();
	mysql_query($sql);
}
header("Location: ".HOST."dashboard");
exit();
echo $sql;
?>
<pre>
<?php
echo "\n\nLocation: ".HOST."$table/$id\n\n";
echo "\n\nGet:\n";
print_r($_GET);
echo "\n\nData:\n";
print_r($data);
echo "\n\nPost:\n";
print_r($_POST);
echo "\n\nFiles:\n";
print_r($_FILES);
?>
</pre>
