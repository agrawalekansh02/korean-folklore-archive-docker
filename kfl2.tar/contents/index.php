<?php $cms->title = 'UCLA Korean Folklore Archive'; ?>

<h1>Welcome to Korean Folklore Online Archive</h1>

<p/>Use this online archive to enter and search fieldwork data. These archive input and search modules were designed to be used with your browser resized to full screen width. Please resize your browser window to cover your screen.


<p/>
<h2>Archive</h2>To enter data into the archive, log-in and use the left menu. If this is your first time adding data to the archive, you will be asked to register as a collector. Once registered, you will be able to add Consultants, Contexts and Data, as well as edit data you have already entered. Only authorized users will be able to enter data.

<p/>
<h2>Search</h2>To search data currently in the archive, click on "Search" on the masthead, or click above. Most searches on the archive are structured as either Boolean or simple keyword searches. Identifying information has been removed from the data to protect confidentiality.


<p/>
<h2>About the Archive</h2>
For a general introduction to the Korean Online Folklore Archive and important information on how to use it, including an overview of the McCune-Reischauer system of Romanization, enter here.