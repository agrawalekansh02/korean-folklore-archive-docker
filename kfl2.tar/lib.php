<?php
define('SECRET','O6oj.Ae32#$kWA');
define('PASSCODE','112');
define('HOST','http://kfl.humnet.ucla.edu/');

mysql_connect('localhost','kfl','%=t%pm7HVxc8v5X');
mysql_select_db('kfl');

include_once('user.php');

function get_token($str) {
    return md5(SECRET . $str);
}

function get_user() {
    return array(
        'collector_id' => 1,
        'ucla_id' => 'yusuf',
        'name' => 'Yusuf Bhabhrawala',
        'is_admin' => false
    );    
}

function get_auth_sql($and = true) {
    global $user;
    $and = ($and) ? ' and' : '';
    if ($user->is_admin()) return '';
    else return "$and collector_id=" . $user->get('id');
}

function get_collector_sql($and = true) {
    global $user;
    $and = ($and) ? ' and' : '';
    return "$and collector_id=" . $user->get('id');
}

function get_record($table, $id, $collector_id=false) {
    global $user;
    if (!$user->is_admin()) $collector_id = $user->get('id');
    $and = ($collector_id) ? "and collector_id=$collector_id" : '';

    $sql = "select * from $table where ${table}_id = $id $and";
    $result = mysql_query($sql);
    if (!$result) return 'Query was unsuccesssful';
    if ($row=mysql_fetch_assoc($result)) return $row;
    else return array();
}

function get_records($table, $collector_id=false) {
    global $user;
    if (!$user->is_admin()) $collector_id = $user->get('id');
    $and = ($collector_id) ? "and collector_id=$collector_id" : '';

    $sql = "select * from $table where 1 $and";
    $result = mysql_query($sql);
    if (!$result) return array();
    $data = array();
    while ($row=mysql_fetch_assoc($result)) $data[] = $row;
    return $data;
}

function check_auth() {
    global $user;
    if (!$user->auth) { exit('Not authorized'); }
    if (!$user->is_user()) { 
        header("Location: " . HOST . "collector"); 
        exit(); 
    }
    return $user;
}
?>
