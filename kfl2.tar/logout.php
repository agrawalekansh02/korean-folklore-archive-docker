<?php
setcookie('kfl','',time() - 3600,'/');
header('Location: /');
?>