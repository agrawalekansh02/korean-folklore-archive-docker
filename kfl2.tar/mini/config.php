<?php
// The name of the website. Generally the title of the home page.
$site_name = 'UCLA Korean Folklore Archive';

// Folder depth is 0, unless site is sub folder.
$folder_depth = 0;

?>
